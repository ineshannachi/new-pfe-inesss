require('dotenv').config();
const express = require('express');
const mysql = require('mysql2'); // Tu peux aussi utiliser mysql2/promise pour simplifier l'usage d'async/await
const path = require('path');

const app = express();
const port = 3007;

// Configuration d'EJS et du dossier de vues
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

// Middleware pour parser les formulaires
app.use(express.urlencoded({ extended: true }));

// Fonction pour attendre MySQL
async function waitForDB() {
  let connected = false;
  while (!connected) {
    try {
      const connection = await mysql.createConnection({
        host: process.env.DB_HOST,
        user: process.env.DB_USER,
        password: process.env.DB_PASSWORD,
        database: process.env.DB_NAME ,
      });
      console.log("✅ Connexion MySQL réussie !");
      connected = true;
      connection.end();
    } catch (error) {
      console.log("❌ MySQL non disponible... Nouvelle tentative dans 3s");
      await new Promise((resolve) => setTimeout(resolve, 3000));
    }
  }
}

// Attendre que MySQL soit prêt, puis créer la pool de connexions
waitForDB().then(() => {
  const pool = mysql.createPool({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME ,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,
  });

  /* Routes */

  // Route d'accueil : Affichage de la liste des stagiaires
  app.get('/', (req, res) => {
    const sql = `
      SELECT id_stage, id_etudiant, nom, prenom, titre, entreprise, date_debut, date_fin 
      FROM stages 
      ORDER BY date_debut DESC
    `;
    pool.query(sql, (err, results) => {
      if (err) {
        console.error(err);
        res.send("Erreur lors de la récupération des stagiaires");
      } else {
        res.render('stages', { stages: results });
      }
    });
  });

  // Route de recherche côté serveur
  app.get('/search', (req, res) => {
    const q = req.query.q;
    if (!q) return res.redirect('/');
    const likeQuery = `%${q}%`;
    const sql = `
      SELECT * FROM stages 
      WHERE titre LIKE ? OR entreprise LIKE ? OR nom LIKE ? OR prenom LIKE ?
      ORDER BY date_debut DESC
    `;
    pool.query(sql, [likeQuery, likeQuery, likeQuery, likeQuery], (err, results) => {
      if (err) {
        console.error(err);
        return res.send("Erreur lors de la recherche des stages");
      }
      res.render('stages', { stages: results });
    });
  });

  // Formulaire d'ajout d'un stagiaire
  app.get('/ajouter-stagiaire', (req, res) => {
    res.render('ajouter-stage', {
      stage: {},
      action: '/ajouter-stagiaire',
      buttonText: 'Ajouter'
    });
  });

  // Traitement de l'ajout (INSERT dans la table "stages")
  app.post('/ajouter-stagiaire', (req, res) => {
    const { id_etudiant, nom, prenom, titre, entreprise, date_debut, date_fin } = req.body;
    const sql = "INSERT INTO stages (id_etudiant, nom, prenom, titre, entreprise, date_debut, date_fin) VALUES (?, ?, ?, ?, ?, ?, ?)";
    pool.query(sql, [id_etudiant, nom, prenom, titre, entreprise, date_debut, date_fin], (err, result) => {
      if (err) {
        console.error(err);
        res.send("Erreur lors de l'ajout du stagiaire");
      } else {
        res.redirect('/');
      }
    });
  });

  // Formulaire de modification d'un stagiaire
  app.get('/modifier-stagiaire/:id', (req, res) => {
    const id = req.params.id;
    const sql = "SELECT * FROM stages WHERE id_stage = ?";
    pool.query(sql, [id], (err, results) => {
      if (err) {
        console.error(err);
        res.send("Erreur lors de la récupération du stagiaire");
      } else if (results.length > 0) {
        res.render('modifier-stage', {
          stage: results[0],
          action: `/modifier-stagiaire/${id}`,
          buttonText: 'Modifier'
        });
      } else {
        res.redirect('/');
      }
    });
  });

  // Traitement de la modification (UPDATE dans la table "stages")
  app.post('/modifier-stagiaire/:id', (req, res) => {
    const id = req.params.id;
    const { id_etudiant, nom, prenom, titre, entreprise, date_debut, date_fin } = req.body;
    const sql = "UPDATE stages SET id_etudiant = ?, nom = ?, prenom = ?, titre = ?, entreprise = ?, date_debut = ?, date_fin = ? WHERE id_stage = ?";
    pool.query(sql, [id_etudiant, nom, prenom, titre, entreprise, date_debut, date_fin, id], (err, result) => {
      if (err) {
        console.error(err);
        res.send("Erreur lors de la modification du stagiaire");
      } else {
        res.redirect('/');
      }
    });
  });

  // Suppression d'un stagiaire (DELETE dans la table "stages")
  app.get('/supprimer-stagiaire/:id', (req, res) => {
    const id = req.params.id;
    const sql = "DELETE FROM stages WHERE id_stage = ?";
    pool.query(sql, [id], (err, result) => {
      if (err) {
        console.error(err);
        res.send("Erreur lors de la suppression du stagiaire");
      } else {
        res.redirect('/');
      }
    });
  });

  // Middleware de gestion des erreurs
  app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ error: err.message });
  });

  // Démarrer le serveur
  app.listen(port, () => {
    console.log(`🚀 Serveur lancé sur http://localhost:${port}`);
  });
});
