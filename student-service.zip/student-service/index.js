require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql2/promise');
const path = require('path');


const app = express();

// Fonction pour attendre que MySQL soit disponible avec un délai maximal
async function waitForDB() {
  let connected = false;
  const maxRetries = 10;  // Limite de tentatives
  let attempts = 0;
  while (!connected && attempts < maxRetries) {
    try {
      const connection = await mysql.createConnection({
        host: process.env.DB_HOST,
        user: process.env.DB_USER,
        password: process.env.DB_PASSWORD,
        database: process.env.DB_NAME,
      });
      console.log("✅ Connexion MySQL réussie !");
      connected = true;
      connection.end();
    } catch (error) {
      attempts++;
      console.log(`❌ MySQL non disponible... Nouvelle tentative dans 3s (${attempts}/${maxRetries})`);
      await new Promise((resolve) => setTimeout(resolve, 3000));
    }
  }
  
  if (!connected) {
    throw new Error("Impossible de se connecter à MySQL après plusieurs tentatives.");
  }
}

// Lancement après confirmation que MySQL est prêt
waitForDB().then(() => {
  const pool = mysql.createPool({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,
  });

  // Configuration d'Express et du moteur de vues EJS
  app.set('view engine', 'ejs');
  app.set('views', path.join(__dirname, 'views'));
  app.use(bodyParser.urlencoded({ extended: false }));
  app.use(express.static(path.join(__dirname, 'public')));

  // Route : Afficher la liste des étudiants
  app.get('/etudiants', async (req, res) => {
    try {
      const [rows] = await pool.query('SELECT * FROM etudiants');
      res.render('index', { etudiants: rows });
    } catch (error) {
      res.status(500).send("Erreur lors de la récupération des étudiants : " + error.message);
    }
  });

  // Route : Afficher le formulaire d'ajout d'un étudiant
  app.get('/etudiants/add', (req, res) => {
    res.render('add');
  });

  // Route : Traiter l'ajout d'un étudiant
  app.post('/etudiants/add', async (req, res) => {
    const { nom, prenom, email, adresse, date_naissance } = req.body;
    try {
      await pool.query(
        'INSERT INTO etudiants (nom, prenom, email, adresse, date_naissance) VALUES (?, ?, ?, ?, ?)',
        [nom, prenom, email, adresse, date_naissance]
      );
      res.redirect('/etudiants');
    } catch (error) {
      res.status(500).send("Erreur lors de l'ajout de l'étudiant : " + error.message);
    }
  });

  // Route : Afficher le formulaire de modification d'un étudiant
  app.get('/etudiants/edit/:id', async (req, res) => {
    const { id } = req.params;
    try {
      const [rows] = await pool.query('SELECT * FROM etudiants WHERE id_etudiant = ?', [id]);
      if (rows.length === 0) {
        res.status(404).send("Étudiant non trouvé");
      } else {
        res.render('edit', { etudiant: rows[0] });
      }
    } catch (error) {
      res.status(500).send("Erreur lors de la récupération de l'étudiant : " + error.message);
    }
  });

  // Route : Traiter la modification d'un étudiant
  app.post('/etudiants/edit/:id', async (req, res) => {
    const { id } = req.params;
    const { nom, prenom, email, adresse, date_naissance } = req.body;
    try {
      await pool.query(
        'UPDATE etudiants SET nom = ?, prenom = ?, email = ?, adresse = ?, date_naissance = ? WHERE id_etudiant = ?',
        [nom, prenom, email, adresse, date_naissance, id]
      );
      res.redirect('/etudiants');
    } catch (error) {
      res.status(500).send("Erreur lors de la modification de l'étudiant : " + error.message);
    }
  });

  // Route : Supprimer un étudiant sans supprimer ses évaluations
  app.post('/etudiants/delete/:id', async (req, res) => {
    const { id } = req.params;
    try {
      // Suppression de l'étudiant sans toucher aux évaluations
      await pool.query('DELETE FROM etudiants WHERE id_etudiant = ?', [id]);
      res.redirect('/etudiants');
    } catch (error) {
      res.status(500).send("Erreur lors de la suppression de l'étudiant : " + error.message);
    }
  });

  // Redirection de la racine vers /etudiants
  app.get('/', (req, res) => {
    res.redirect('/etudiants');
  });

  // Middleware de gestion des erreurs
  app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ error: err.message });
  });

  // Démarrer le serveur
  const PORT = 3011;
  app.listen(PORT, () => {
    console.log(`🚀 Serveur démarré sur http://localhost:${PORT}`);
  });
});
