// Importation des modules nécessaires
const express = require('express');
const mysql = require('mysql2');
const path = require('path');
const http = require('http');
const socketIo = require('socket.io');
require('dotenv').config(); // Chargement des variables d'environnement

// Initialisation de l'application Express et du serveur HTTP
const app = express();
const port = 3022;
const server = http.createServer(app);
const io = socketIo(server);

// Configuration du moteur de vues EJS et du dossier de vues
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Middleware pour analyser les données des formulaires et servir les fichiers statiques
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Fonction pour attendre que MySQL soit disponible
async function waitForDB() {
  let connected = false;
  while (!connected) {
    try {
      const connection = await mysql.createConnection({
        host: process.env.DB_HOST,
        user: process.env.DB_USER,
        password: process.env.DB_PASSWORD,
        database: process.env.DB_NAME,
      });
      console.log("✅ Connexion MySQL réussie !");
      connected = true;
      connection.end(); // Fermeture de la connexion après vérification
    } catch (error) {
      console.log("❌ MySQL non disponible... Nouvelle tentative dans 3s");
      await new Promise((resolve) => setTimeout(resolve, 3000));
    }
  }
}

// Fonction pour créer la table "messages" si elle n'existe pas
function createMessagesTable(pool, callback) {
  const createTableQuery = `
    CREATE TABLE IF NOT EXISTS messages (
      id INT AUTO_INCREMENT PRIMARY KEY,
      id_user INT NOT NULL,

      sender VARCHAR(255) NOT NULL,
      receiver VARCHAR(255) NOT NULL,
      message TEXT NOT NULL,
      date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
  `;
  pool.query(createTableQuery, (err, result) => {
    if (err) {
      console.error("❌ Erreur lors de la création de la table 'messages':", err);
      callback(err);
    } else {
      console.log("✅ Table 'messages' vérifiée ou créée avec succès.");
      callback(null);
    }
  });
}

// Lancement après confirmation que MySQL est prêt
waitForDB().then(() => {
  // Création du pool de connexions MySQL
  const pool = mysql.createPool({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,
  });

  // Vérifier la connexion au pool MySQL
  pool.getConnection((err, connection) => {
    if (err) {
      console.error('Erreur de connexion au pool MySQL:', err);
    } else {
      console.log('Connecté au pool MySQL');
      connection.release();
    }
  });

  // Créer la table "messages" puis démarrer l'application
  createMessagesTable(pool, (err) => {
    if (err) {
      console.error("Impossible de créer ou vérifier la table 'messages'. Arrêt de l'application.");
      process.exit(1);
    } else {
      // Définition des routes
      app.get('/', (req, res) => {
        res.render('index');
      });

      app.get('/chat', (req, res) => {
        pool.query('SELECT * FROM messages ORDER BY date DESC', (err, results) => {
          if (err) {
            console.error('Erreur lors de la récupération des messages:', err);
            res.status(500).send('Erreur interne du serveur');
          } else {
            res.render('chat', { messages: results });
          }
        });
      });

      // Gestion de Socket.io pour la messagerie en temps réel
      io.on('connection', (socket) => {
        console.log("🔵 Un utilisateur est connecté au chat");

        // Réception d'un message et insertion dans la base de données
        socket.on('send_message', (data) => {
          console.log("📩 Message reçu:", data);
          pool.query(
            'INSERT INTO messages (sender, receiver, message) VALUES (?, ?, ?)',
            [data.sender, data.receiver, data.message],
            (err, result) => {
              if (err) {
                console.error("Erreur d'insertion dans la base de données:", err);
              } else {
                console.log("📥 Message inséré dans la base de données");
                data.id = result.insertId;  // Ajout de l'ID généré
                io.emit('receive_message', data); // Diffuser le message à tous les clients
              }
            }
          );
        });

        // Suppression d'un message
        socket.on('delete_message', (data) => {
          const messageId = data.messageId;
          pool.query('DELETE FROM messages WHERE id = ?', [messageId], (err) => {
            if (err) {
              console.error("Erreur lors de la suppression du message:", err);
            } else {
              console.log(`🗑️ Message avec l'ID ${messageId} supprimé`);
              io.emit('message_deleted', messageId);
            }
          });
        });

        // Gestion de la déconnexion
        socket.on('disconnect', () => {
          console.log("🔴 Un utilisateur s'est déconnecté du chat");
        });
      });

      // Démarrage du serveur
      server.listen(port, () => {
        console.log(`🚀 Serveur lancé sur http://localhost:${port}`);
      });
    }
  });
});
