require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql2/promise');
const path = require('path');

const app = express();

async function waitForDB() {
  let connected = false;
  let pool;
  while (!connected) {
    try {
      pool = mysql.createPool({
        host: process.env.DB_HOST,
        user: process.env.DB_USER,
        password: process.env.DB_PASSWORD,
        database: process.env.DB_NAME,
        waitForConnections: true,
        connectionLimit: 10,
        queueLimit: 0,
      });
      await pool.query('SELECT 1');
      console.log("✅ Connexion MySQL réussie !");
      connected = true;
    } catch (error) {
      console.log("❌ MySQL non disponible... Nouvelle tentative dans 3s");
      await new Promise((resolve) => setTimeout(resolve, 3000));
    }
  }
  return pool;
}

waitForDB().then((pool) => {
  app.set('view engine', 'ejs');
  app.set('views', path.join(__dirname, 'views'));

  app.use(bodyParser.urlencoded({ extended: false }));
  app.use(express.static(path.join(__dirname, 'public')));

  // Route d'accueil
  app.get('/', (req, res) => {
    res.render('index');  // Utilise la vue index.ejs
  });

  app.get('/offres', async (req, res) => {
    try {
      const [rows] = await pool.query('SELECT * FROM offres_de_stage ORDER BY date_creation DESC');
      res.render('offres', { offres: rows });
    } catch (error) {
      res.status(500).send(error.message);
    }
  });

  app.get('/offres/nouveau', (req, res) => {
    res.render('offreStageForm');
  });

  app.post('/offres', async (req, res) => {
    const { titre, entreprise, description, date_debut, date_fin, lieu, email, contact } = req.body;
    try {
      await pool.query(
        `INSERT INTO offres_de_stage 
        (id_etudiant, titre, entreprise, description, date_debut, date_fin, lieu, email, contact, date_creation) 
        VALUES (NULL, ?, ?, ?, ?, ?, ?, ?, ?, NOW())`,
        [titre, entreprise, description, date_debut, date_fin, lieu, email, contact]
      );
      res.redirect('/offres');
    } catch (error) {
      res.status(500).send(error.message);
    }
  });

  app.get('/offres/:id/edit', async (req, res) => {
    const { id } = req.params;
    try {
      const [rows] = await pool.query('SELECT * FROM offres_de_stage WHERE id_offre = ?', [id]);
      if (rows.length === 0) return res.status(404).send('Offre non trouvée');
      res.render('editOffre', { offre: rows[0] });
    } catch (error) {
      res.status(500).send(error.message);
    }
  });

  app.post('/offres/:id/edit', async (req, res) => {
    const { id } = req.params;
    const { titre, entreprise, description, date_debut, date_fin, lieu, email, contact } = req.body;
    try {
      await pool.query(
        'UPDATE offres_de_stage SET titre = ?, entreprise = ?, description = ?, date_debut = ?, date_fin = ?, lieu = ?, email = ?, contact = ? WHERE id_offre = ?',
        [titre, entreprise, description, date_debut, date_fin, lieu, email, contact, id]
      );
      res.redirect('/offres');
    } catch (error) {
      res.status(500).send(error.message);
    }
  });

  

 
  app.post('/offres/:id/delete', async (req, res) => {
    const { id } = req.params;
    try {
        await pool.query('DELETE FROM offres_de_stage WHERE id_offre = ?', [id]);
        res.redirect('/offres');
    } catch (error) {
        res.status(500).send(error.message);
    }
});



  const PORT = 3025;
  app.listen(PORT, () => {
    console.log(`Serveur démarré sur http://localhost:${PORT}`);
  });
});
